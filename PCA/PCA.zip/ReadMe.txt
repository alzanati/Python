Link:	https://archive.ics.uci.edu/ml/datasets/Iris


############################	summary     #############################################
The iris dataset contains measurements for 150 iris flowers from three different species.

The three classes in the Iris dataset are:

    Iris-setosa (n=50)
    Iris-versicolor (n=50)
    Iris-virginica (n=50)

And the four features of in Iris dataset are:

    sepal length in cm
    sepal width in cm
    petal length in cm
    petal width in cm
##########################################################################################

